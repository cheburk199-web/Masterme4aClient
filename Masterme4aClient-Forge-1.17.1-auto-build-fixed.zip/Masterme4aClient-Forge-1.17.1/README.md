# Masterme4a Client — Forge 1.17.1

A visual-only Minecraft HUD mod. It does not add cheats, combat automation, or gameplay advantages.

## Build

Requires JDK 16 and Gradle 7.3.3.

```bash
gradle --no-daemon build
```

The mod JAR is created in `build/libs/`.

## HUD

Displays the Masterme4a label, FPS, player coordinates, and facing direction. HUD options are stored in the Forge client config.
