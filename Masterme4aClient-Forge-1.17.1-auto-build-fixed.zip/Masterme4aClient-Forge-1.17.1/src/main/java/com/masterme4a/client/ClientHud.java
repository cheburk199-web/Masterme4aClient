package com.masterme4a.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = "masterme4a", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientHud {
    private static final int ACCENT = 0xFFB45CFF;
    private static final int TEXT = 0xFFFFFFFF;
    private static long fpsWindowStart = System.nanoTime();
    private static int framesInWindow = 0;
    private static int displayedFps = 0;

    private static int currentFps() {
        framesInWindow++;
        long now = System.nanoTime();
        long elapsed = now - fpsWindowStart;
        if (elapsed >= 1_000_000_000L) {
            displayedFps = (int) Math.round(framesInWindow * 1_000_000_000.0 / elapsed);
            framesInWindow = 0;
            fpsWindowStart = now;
        }
        return displayedFps;
    }

    private ClientHud() {}

    @SubscribeEvent
    public static void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;

        PoseStack pose = event.getMatrixStack();
        List<String> lines = new ArrayList<>();
        lines.add("§dMASTERME4A");
        if (ClientConfig.SHOW_FPS.get()) lines.add("FPS: " + currentFps());
        if (ClientConfig.SHOW_COORDINATES.get()) {
            lines.add(String.format(java.util.Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                    player.getX(), player.getY(), player.getZ()));
        }
        if (ClientConfig.SHOW_DIRECTION.get()) {
            lines.add("Направление: " + directionName(player.getDirection()));
        }

        int x = 8;
        int y = 8;
        int width = 0;
        for (String line : lines) width = Math.max(width, mc.font.width(line));
        int height = lines.size() * 11 + 8;
        int opacity = ClientConfig.BACKGROUND_OPACITY.get();
        int background = (opacity << 24) | 0x160D24;
        GuiComponent.fill(pose, x - 4, y - 4, x + width + 8, y + height, background);
        GuiComponent.fill(pose, x - 4, y - 4, x - 1, y + height, ACCENT);

        for (int i = 0; i < lines.size(); i++) {
            int color = i == 0 ? ACCENT : TEXT;
            mc.font.draw(pose, lines.get(i), x, y + i * 11, color);
        }
    }

    private static String directionName(Direction direction) {
        switch (direction) {
            case NORTH: return "Север";
            case SOUTH: return "Юг";
            case EAST: return "Восток";
            case WEST: return "Запад";
            default: return direction.getName();
        }
    }
}
