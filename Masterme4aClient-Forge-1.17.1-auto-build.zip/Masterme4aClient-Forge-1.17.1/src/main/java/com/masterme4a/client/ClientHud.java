package com.masterme4a.client;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Direction;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ClientHud {
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.level == null || player == null || mc.options.hideGui) return;

        MatrixStack pose = event.getMatrixStack();
        int x = 8;
        int y = 8;
        int accent = ClientConfig.ACCENT_COLOR.get();
        int opacity = ClientConfig.OPACITY.get();
        int panel = (opacity << 24) | 0x10051F;
        int white = 0xFFEFEFFF;
        int muted = 0xFFD9B8FF;

        String[] lines = new String[5];
        int count = 0;

        if (ClientConfig.SHOW_BRAND.get()) lines[count++] = "Masterme4a";
        if (ClientConfig.SHOW_FPS.get()) lines[count++] = "FPS: " + mc.fps;
        if (ClientConfig.SHOW_COORDS.get()) {
            lines[count++] = String.format("XYZ: %.1f / %.1f / %.1f",
                    player.getX(), player.getY(), player.getZ());
        }
        if (ClientConfig.SHOW_DIRECTION.get()) {
            Direction d = player.getDirection();
            lines[count++] = "Направление: " + directionName(d);
        }

        if (count == 0) return;
        int width = 0;
        for (int i = 0; i < count; i++) {
            width = Math.max(width, mc.font.width(lines[i]));
        }
        width += 16;
        int height = count * 12 + 10;

        mc.gui.fill(pose, x, y, x + width, y + height, panel);
        mc.gui.fill(pose, x, y, x + 2, y + height, 0xFF000000 | accent);

        for (int i = 0; i < count; i++) {
            int color = (i == 0 && ClientConfig.SHOW_BRAND.get()) ? (0xFF000000 | accent) : white;
            mc.font.draw(pose, lines[i], x + 8, y + 6 + i * 12, color);
        }
    }

    private String directionName(Direction direction) {
        switch (direction) {
            case NORTH: return "Север";
            case SOUTH: return "Юг";
            case EAST: return "Восток";
            case WEST: return "Запад";
            default: return direction.getName();
        }
    }
}
