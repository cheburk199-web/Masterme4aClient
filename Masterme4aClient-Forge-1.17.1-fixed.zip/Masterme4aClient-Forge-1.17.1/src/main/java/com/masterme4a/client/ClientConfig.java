package com.masterme4a.client;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue SHOW_BRAND;
    public static final ForgeConfigSpec.BooleanValue SHOW_FPS;
    public static final ForgeConfigSpec.BooleanValue SHOW_COORDS;
    public static final ForgeConfigSpec.BooleanValue SHOW_DIRECTION;
    public static final ForgeConfigSpec.IntValue ACCENT_COLOR;
    public static final ForgeConfigSpec.IntValue OPACITY;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("hud");
        SHOW_BRAND = b.comment("Show Masterme4a branding").define("showBrand", true);
        SHOW_FPS = b.comment("Show frames per second").define("showFps", true);
        SHOW_COORDS = b.comment("Show player coordinates").define("showCoordinates", true);
        SHOW_DIRECTION = b.comment("Show facing direction").define("showDirection", true);
        ACCENT_COLOR = b.comment("Accent color in RGB hex, default purple").defineInRange("accentColor", 0xC43CFF, 0, 0xFFFFFF);
        OPACITY = b.comment("Panel opacity (0-255)").defineInRange("opacity", 150, 0, 255);
        b.pop();
        SPEC = b.build();
    }

    private ClientConfig() {}
}
